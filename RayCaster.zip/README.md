# YetAnotherRayCaster
Best room walking simulator GOTY 2019


Raycasting engine with a bit of clever procedural graphics.
